# SIN Online — L'Éveil du Roi Rouge

Prototype web 2D jouable dans un navigateur, adapté au téléphone et à l'ordinateur. Inclut une page de jeu, inscription/connexion, mots de passe hachés, sauvegarde PostgreSQL des personnages/positions et synchronisation des déplacements entre joueurs connectés.

## Déploiement sur Render
1. Importer les fichiers de ce dossier à la racine du dépôt GitHub `sin-online` (pas le ZIP seul).
2. Dans Render, choisir **New → Blueprint**, connecter GitHub et sélectionner `sin-online`.
3. Render lit `render.yaml` et demande de créer le service et la base de données. Vérifier les plans et tarifs affichés avant de confirmer : les plans de base peuvent être payants.
4. Après le déploiement, ouvrir l'URL Render fournie et tester `/health`, l'inscription puis la connexion depuis deux navigateurs.

## Lancer en local
Nécessite Node.js 20+ et PostgreSQL. Définir `DATABASE_URL` et `JWT_SECRET`, puis `npm install` et `npm start`.

## État et limites
Ceci est un prototype de départ, pas un MMORPG commercial prêt pour la production. Il n'inclut pas encore combat, quêtes, inventaire, chat, modération, limitation anti-abus, migrations et supervision de production. Tester et renforcer la sécurité avant d'ouvrir largement aux joueurs. Ne jamais partager de mots de passe ou de secrets.
