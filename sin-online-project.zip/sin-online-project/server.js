const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL.includes('localhost') ? false : { rejectUnauthorized: false } }) : null;
const online = new Map();

app.use(express.json({ limit: '20kb' }));
app.use(express.static('public'));
app.get('/health', (_req, res) => res.json({ ok: true, game: 'SIN Online', database: !!pool }));

async function initDb() {
  if (!pool) return;
  await pool.query(`CREATE TABLE IF NOT EXISTS players (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(20) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    character_name VARCHAR(24) NOT NULL,
    level INTEGER NOT NULL DEFAULT 1,
    xp INTEGER NOT NULL DEFAULT 0,
    x INTEGER NOT NULL DEFAULT 450,
    y INTEGER NOT NULL DEFAULT 300,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
}
function requireDb(req, res, next) {
  if (!pool) return res.status(503).json({ error: 'La base de données n’est pas configurée. Ajoutez DATABASE_URL dans les variables d’environnement.' });
  next();
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Session invalide. Reconnectez-vous.' }); }
}
app.post('/api/register', requireDb, async (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    const characterName = String(req.body.characterName || username).trim();
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Identifiant : 3 à 20 caractères, lettres, chiffres ou _.' });
    if (password.length < 8 || password.length > 100) return res.status(400).json({ error: 'Le mot de passe doit contenir au moins 8 caractères.' });
    if (characterName.length < 2 || characterName.length > 24) return res.status(400).json({ error: 'Nom du personnage : 2 à 24 caractères.' });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query('INSERT INTO players(username,password_hash,character_name) VALUES($1,$2,$3) RETURNING id,username,character_name,level,xp,x,y', [username, hash, characterName]);
    const player = result.rows[0];
    const token = jwt.sign({ id: player.id, username: player.username }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, player });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Cet identifiant est déjà utilisé.' });
    console.error(e); res.status(500).json({ error: 'Impossible de créer le compte.' });
  }
});
app.post('/api/login', requireDb, async (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const result = await pool.query('SELECT * FROM players WHERE username=$1', [username]);
    const player = result.rows[0];
    if (!player || !(await bcrypt.compare(String(req.body.password || ''), player.password_hash))) return res.status(401).json({ error: 'Identifiant ou mot de passe incorrect.' });
    const token = jwt.sign({ id: player.id, username: player.username }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, player: { id: player.id, username: player.username, character_name: player.character_name, level: player.level, xp: player.xp, x: player.x, y: player.y } });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Connexion impossible.' }); }
});
app.get('/api/me', requireDb, auth, async (req, res) => {
  const result = await pool.query('SELECT id,username,character_name,level,xp,x,y FROM players WHERE id=$1', [req.user.id]);
  if (!result.rowCount) return res.status(404).json({ error: 'Personnage introuvable.' });
  res.json({ player: result.rows[0] });
});

io.use((socket, next) => {
  try { socket.player = jwt.verify(socket.handshake.auth?.token, JWT_SECRET); next(); }
  catch { next(new Error('Connexion requise')); }
});
io.on('connection', async (socket) => {
  if (!pool) return socket.disconnect(true);
  try {
    const result = await pool.query('SELECT id,username,character_name,level,xp,x,y FROM players WHERE id=$1', [socket.player.id]);
    if (!result.rowCount) return socket.disconnect(true);
    const p = result.rows[0];
    const entry = { socketId: socket.id, id: p.id, username: p.username, name: p.character_name, level: p.level, x: p.x, y: p.y };
    online.set(String(p.id), entry);
    socket.emit('world:init', { self: entry, players: [...online.values()] });
    socket.broadcast.emit('world:join', entry);
    socket.on('player:move', async (pos) => {
      const current = online.get(String(p.id)); if (!current) return;
      const x = Math.max(24, Math.min(876, Math.round(Number(pos?.x) || current.x)));
      const y = Math.max(24, Math.min(576, Math.round(Number(pos?.y) || current.y)));
      current.x = x; current.y = y;
      socket.broadcast.emit('player:moved', { id: p.id, x, y });
      try { await pool.query('UPDATE players SET x=$1,y=$2 WHERE id=$3', [x,y,p.id]); } catch (e) { console.error(e); }
    });
    socket.on('disconnect', () => { online.delete(String(p.id)); io.emit('world:leave', { id: p.id }); });
  } catch (e) { console.error(e); socket.disconnect(true); }
});

(async () => {
  if (!JWT_SECRET && process.env.NODE_ENV === 'production') throw new Error('JWT_SECRET est obligatoire en production.');
  if (!process.env.JWT_SECRET) process.env.JWT_SECRET = require('crypto').randomBytes(32).toString('hex');
  await initDb();
  server.listen(PORT, () => console.log(`SIN Online listening on ${PORT}`));
})().catch(e => { console.error(e); process.exit(1); });
